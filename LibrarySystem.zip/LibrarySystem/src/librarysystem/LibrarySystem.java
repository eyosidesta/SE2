

/*  
    Eyosias Desta
    ATR/3173/08
    Using Singleton Architecture
*/
package librarysystem;

import java.util.Scanner;

public class LibrarySystem {
    
    private String auther = "Addis Alemayehu, Bealu Girma";
    private String title = "fikir eske mekabir";
    
    private static LibrarySystem book = null;
    private static boolean isLoanedOut = false;
    private static boolean haveBook = false;

    public static void main(String[] args) {
        // TODO code application logic here
        LibrarySystem library = new LibrarySystem();
        System.out.println("Start Testing One Book borrow here");
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your name to borrow book: ");
        String name = input.nextLine();
        System.out.println( name + " asked to borrow book");
        if(borrowBook() != null) {
            System.out.println("The Auther and Title of the book is " + " " + library.getAutherAndTitle());
        }
        else {
            System.out.println("The Book you asked to borrow is already borrowed");
        }
        returnBook();
        System.out.println(name + " returned the book");
        Scanner inputtwo = new Scanner(System.in);
        System.out.print("Enter your name to borrow the returned book: ");
        String nametwo = inputtwo.nextLine();
        System.out.println(nametwo + " asked to borrow the book");
        if(borrowBook() != null) {
            System.out.println("The Auther and Title of the book is " + " " + library.getAutherAndTitle());
        }
        else {
            System.out.println("The Book you asked to borrow is already borrowed");
        }
        System.out.print("Enter your name to borrow book: ");
        Scanner inputthree = new Scanner(System.in);
        String namethree = inputthree.nextLine();
        System.out.println(namethree + " asked to borrow the book");
        if(borrowBook() != null) {
            System.out.println("The Auther and Title of the book is " + " " + library.getAutherAndTitle());
        }
        else {
            System.out.println("The Book you asked to borrow is already borrowed");
        }
        System.out.println("End Testing One book borrow");
    }
    
    public static LibrarySystem borrowBook() {
        if(!isLoanedOut) {
            if(book == null) {
                book = new LibrarySystem();
            }
            isLoanedOut = true;
            haveBook = true;
            return book;
        }else {
            haveBook = false;
            return null;
        }
    }
    public static void returnBook(LibrarySystem book) {
        isLoanedOut = false;
    }
    public String getAuther() {
        return auther;
    }
    public String getTitle() {
        return title;
    }
    public String getAutherAndTitle() {
        if(borrowBook() == null) {
            return getTitle() + " written by " + getAuther();
        }
        else {
            return null;
        }
    }
    public static void returnBook() {
        returnBook(borrowBook());
    }
    
    
}
