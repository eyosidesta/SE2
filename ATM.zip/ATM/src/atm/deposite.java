
/* 
    Eyosias Desta 
    ATR/3173/08
    Using Peer to Peer Architecture
*/
package atm;

import java.util.Scanner;


public class deposite {
    
    public static void AddBirr() {
        System.out.print("Enter amount of money to deposite: ");
        Scanner deposite = new Scanner(System.in);
        double birr = deposite.nextDouble();
        ATM.birr += birr;
        System.out.println("Successfully deposited " + birr +  " birr now your balance is " + ATM.birr);
        System.out.println("**********************************");
        Scanner choice = new Scanner(System.in);
        ATM.choice();
    }
    
}
