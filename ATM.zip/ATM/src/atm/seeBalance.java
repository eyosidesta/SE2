
/* 
    Eyosias Desta 
    ATR/3173/08
    Using Peer to Peer Architecture
*/
package atm;

import java.util.Scanner;

public class seeBalance {

    public static void seeBalance() {
        System.out.println("your balance is " + ATM.birr);
        System.out.println("**********************************");
        ATM.choice();
    }
}
