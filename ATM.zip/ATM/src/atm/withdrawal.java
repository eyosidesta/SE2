
/* 
    Eyosias Desta 
    ATR/3173/08
    Using Peer to Peer Architecture
*/
package atm;

import java.util.Scanner;

public class withdrawal {
    
    public static void withdraw() {
        System.out.print("Enter amount of money to withdraw: ");
        Scanner withdraw = new Scanner(System.in);
        double birr = withdraw.nextDouble();
        if(ATM.birr < birr) {
            System.out.println("your balance is insufficient");
            System.out.println("**********************************");
            ATM.choice();
        }
        else {
            ATM.birr -= birr;
            System.out.println("you successfully withdraw " + birr + " birr now your balance is "+ ATM.birr);
            System.out.println("**********************************");
            ATM.choice();
        }
        
    }
}
