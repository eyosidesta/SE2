
/* 
    Eyosias Desta 
    ATR/3173/08
    Using Peer to Peer Architecture
*/
package atm;

import java.util.InputMismatchException;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class ATM {

    static double birr = 50;
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Welcome to Habesha bank of Ethiopia");
        choice();
    }
    public static void choice() {
        Scanner input = new Scanner(System.in);
       
        try {
        
        System.out.print("Enter your choice \n1 for deposite\n2 for withdraw\n3 for transfer\n4 to see balance\nEnter 0 to exit: ");
        int choice = input.nextInt();
        
        if(choice == 1) {
            deposite.AddBirr();
        }
        else if(choice == 2) {
            withdrawal.withdraw();
        }
        else if(choice == 3) {
            transfer.transfer();
        }
        else if(choice == 4) {
            seeBalance.seeBalance();
        }
        else if(choice == 0) {
            exit();
        }
        else {
            System.out.println("The value is not valid please enter valid number");
            System.out.println("***************************************");
            choice();
        }
    }
    catch(InputMismatchException e) {
            System.out.println("the value you entered is invalid please enter valid number");
            System.out.println("***************************************");
            choice();
        }
    }
    
}
