
/* 
    Eyosias Desta 
    ATR/3173/08
    Using Peer to Peer Architecture
*/
package atm;

import java.util.Scanner;

public class transfer {
    
    public static void transfer() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an account to tansfer");
        double take = input.nextDouble();
        if(take >= 1000000000*1000 || take <= 1000000000*10000) {
            Scanner inputBirr = new Scanner(System.in);
            System.out.print("Enter amount of money to transfer: ");
            double takeBirr = inputBirr.nextDouble();
            if(ATM.birr < takeBirr) {
                System.out.println("your balance is insufficinet to transfer");
                System.out.println("**********************************");
                transfer();
            }
            else {
                ATM.birr -= takeBirr;
                System.out.println("you transfer " + takeBirr + " birr successfully now your balance is " + ATM.birr);
                System.out.println("**********************************");
                ATM.choice();
            }
        }
        else {
            System.out.println("Please enter 13 digits acount number to transfer \nsince our bank acounts number of digit is 13");
            System.out.println("**********************************");
        }   transfer();
    }
    
}
